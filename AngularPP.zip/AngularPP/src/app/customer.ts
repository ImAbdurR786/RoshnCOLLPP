export class Customer {
    accountNo:  number;
    name: String;
    pin: number;
    phonenum : number;
    balance: number;

    constructor(name:String,pin:number,phonenum:number, balance:number){
    this.name = name;
    this.pin = pin;
    this.phonenum = phonenum;
    this.balance = balance;
}

}
