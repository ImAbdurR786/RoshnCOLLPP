import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Transaction } from '../transaction';

@Component({
  selector: 'app-transfer-fund',
  templateUrl: './transfer-fund.component.html',
  styleUrls: ['./transfer-fund.component.css']
})
export class TransferFundComponent implements OnInit {

  bankService: BankService;
  transferString: String;

  constructor(bankService: BankService) {
    this.bankService = bankService;
   }


  transferBalance(data:any){
    this.bankService.transferBalance(data).subscribe
    (data=>{
      this.transferString = data;
      console.log(data);
    }
    );
  }

  ngOnInit() {
  }

}
