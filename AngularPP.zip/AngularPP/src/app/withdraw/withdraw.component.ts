import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Transaction } from '../transaction';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  bankService: BankService;
  withdrawString: String;
  constructor(bankService: BankService) { 
    this.bankService = bankService;
  }

  withdrawBalance(data: any){
   this.bankService.withdrawBalance(data).subscribe(
     data=>{
       this.withdrawString = data;
      console.log(data);
     }
   );
  }
  
  ngOnInit() {
  }

}
