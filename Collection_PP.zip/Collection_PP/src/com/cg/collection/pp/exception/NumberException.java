package com.cg.collection.pp.exception;

public class NumberException extends RuntimeException {
	public NumberException() {

	}

	public NumberException(String message) {
		super(message);
	}
}
