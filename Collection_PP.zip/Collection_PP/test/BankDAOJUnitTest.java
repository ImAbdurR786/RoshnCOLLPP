import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import com.cg.collection.pp.dao.*;
/**
 *
 * @author Raja
 */
public class BankDAOJUnitTest {
    

    BankDAOImpl bankdao; 
    
    @Before 
    public void BeforeAllMethod(){        
    bankdao = new BankDAOImpl();
    }
    
    @Test
    public void TestShowBalance(){
    Long l = Long.valueOf(98765432);
    int actualBalance = bankdao.getHashMap().get(l).getBalance();
    int expectedBalance = 1000;
    assertEquals(actualBalance,expectedBalance);
    }
    
    @Test
    public void TestDeposit(){
       int actualBalance =  bankdao.depositeMoney(98765432, 100 , "Deposited" );
       int expectedBalance = 1100;
       assertEquals(actualBalance,expectedBalance);
    }

    @Test
    public void TestWithdraw(){
    int actualBalance = bankdao.withdrawMoney(98765432, 200 , "withdraw");
    int expectedBalance = 900;
    assertEquals(actualBalance,expectedBalance);
    }

    @Test 
    public void TestFundTransfer(){
    bankdao.fundTransfer(98765432, 98765433 , 700, 1300, "Transfer" , "Recieve");
    int actualTransfer =  200;
    int expectedTransfer = 200;
    assertEquals(actualTransfer, expectedTransfer);
    }
}
